//
//  AboutMeApp.swift
//  AboutMe
//
//  Created by Tyler Anderson on 11.02.2026.
//

import SwiftUI

@main
struct AboutMeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
