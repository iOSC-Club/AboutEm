//
//  MoreView.swift
//  AboutMe
//
//  Created by Tyler Anderson on 11.02.2026.
//

import SwiftUI

struct MoreView: View {
    var body: some View {
        NavigationStack {
            Form {
                Section("Skills") {
                    Text("Ice")
                    Text("Water")
                    Text("Salt")
                }
                
                Section("Ice Cream") {
                    Text("Chocolate")
                    Text("Vanilla")
                    Text("yucky mint chip")
                }
                
            }
            .navigationTitle(Text("More Info"))
        }
    }
}

#Preview {
    MoreView()
}
