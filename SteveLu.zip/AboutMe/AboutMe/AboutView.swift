//
//  Aboutview.swift
//  AboutMe
//
//  Created by Tyler Anderson on 11.02.2026.
//


//
//  AboutView.swift
//  AboutMe
//
//  Created by Tyler Anderson on 11.02.2026.
//

import SwiftUI

struct AboutView: View {
    var hobbies = ["Swift", "Building", "Awesome", "Things"]
    
    var body: some View {
        ZStack {
            Color.red
                .opacity(0.67)
                .ignoresSafeArea()
            
            
            VStack {
                Image("Primary")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(30)
                    .shadow(color: .black, radius: 20)
                    .padding()
                    
                Text("Hey, I'm Steve Lu")
                    .font(.largeTitle)
                    .bold()
                    .fontDesign(.rounded)

                
                Text ("I love \(hobbies.formatted(.list(type: .and)))")

                
                HStack {
                    Image(systemName: "iphone.gen3")
                    Image(systemName: "macbook")
                    Image(systemName: "vision.pro")
                    Image(systemName: "homepod.fill")
                    Image(systemName: "earpods")
                }
                .imageScale(.large)
                .padding()
                .glassEffect(.regular.tint(.gray).interactive())
                .shadow(radius: 5)
                
                Spacer()
                    .frame(height: 20)
                
                Text("Fun Fact")
                    .font(.title3)
                    .bold()
                
                Text("I enjoy birding")
                
                Spacer()
                    .frame(height: 20)
                
                Text("Favorite Apple Product")
                    .font(.title3)
                    .bold()
                
                Text("Macbook")
            }
            .padding()
            .multilineTextAlignment(.center)
        }
        
    }
}

#Preview {
    AboutView()
}
