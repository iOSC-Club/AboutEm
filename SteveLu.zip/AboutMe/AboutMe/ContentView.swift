//
//  ContentView.swift
//  AboutMe
//
//  Created by Tyler Anderson on 11.02.2026.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            
            Tab("About", systemImage: "person") {
                AboutView()
            }
            
            Tab("Contact", systemImage: "phone") {
                ContactView()
            }
            
            Tab("More", systemImage: "ellipsis") {
                MoreView()
            }

        }
        .glassEffect(.regular.tint(.blue).interactive())
    }
}

#Preview {
    ContentView()
}
