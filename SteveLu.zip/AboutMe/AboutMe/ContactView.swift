//
//  ContactView.swift
//  AboutMe
//
//  Created by Tyler Anderson on 11.02.2026.
//

import SwiftUI

struct ContactView: View {
    var body: some View {
        NavigationStack {
            VStack {
                Link(destination: URL(string: "instagram.com/apple")!) { // ! force unwraps optional
                    Text("facebook")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonStyle(.borderedProminent)
                .buttonBorderShape(.roundedRectangle(radius: 20))
                
                Link(destination: URL(string: "instagram.com/apple")!) { // ! force unwraps optional
                    Text("apple")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonStyle(.borderedProminent)
                .buttonBorderShape(.roundedRectangle(radius: 20))
                
                Link(destination: URL(string: "instagram.com/apple")!) { // ! force unwraps optional
                    Text("amazon")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonStyle(.borderedProminent)
                .buttonBorderShape(.roundedRectangle(radius: 20))
                
                Link(destination: URL(string: "instagram.com/apple")!) { // ! force unwraps optional
                    Text("netflix")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonStyle(.borderedProminent)
                .buttonBorderShape(.roundedRectangle(radius: 20))
                
                Link(destination: URL(string: "instagram.com/apple")!) { // ! force unwraps optional
                    Text("google")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonStyle(.borderedProminent)
                .buttonBorderShape(.roundedRectangle(radius: 20))
            }
            .navigationTitle(Text("Contact"))
        }
    }
}

#Preview {
    ContactView()
}
