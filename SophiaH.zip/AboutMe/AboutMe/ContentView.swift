//
//  ContentView.swift
//  AboutMe
//
//  Created by Hamza Wako on 2/11/26.
//

import SwiftUI

struct ContentView: View {
    let hobbies = ["longboarding", "fashion", "movies", "food"]
    var body: some View {
        TabView{
            Tab("About" systemImage: "person"){
                AboutView()
                
                Tab("Contact", systemImage: "phone"){ ContactView()}
            }
            
            }
        }
        ZStack{
            Color.blue
                .opacity(0.2)
            VStack {
                Image("Primary")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(20)
                    .shadow(radius: 20)
                
                Text("Hey, I'm Sophia")
                    .font(.largeTitle)
                    .bold()
                    .fontDesign(.serif)
                
                Text("I love \(hobbies.formatted())")
                
                HStack{
                    Image(systemName:"iphone")
                    Image(systemName: "macbook")
                    Image(systemName: "ipad")
                    Image(systemName: "applewatch")
                    
                }
                .imageScale(.large)
                .padding()
                .glassEffect(.regular.tint(.blue).interactive())
                
                Spacer()
                    .frame(height: 20)
                
                Text("Fun Fact")
                    .font(.title3)
                    .bold()
                
                Text("I was a top 1% chatGPT user")
                
                Text("Favorite Apple Product")
                    .font(.title3)
                    .bold()
                
                Text("iPhone")
                
                
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
