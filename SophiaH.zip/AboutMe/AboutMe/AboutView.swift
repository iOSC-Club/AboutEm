//
//  AboutView.swift
//  AboutMe
//
//  Created by Hamza Wako on 2/11/26.
//

import SwiftUI

struct AboutView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    AboutView()
}
