//
//  ContactView.swift
//  AboutMe
//
//  Created by Hamza Wako on 2/11/26.
//

import SwiftUI

struct ContactView: View {
    var body: some View {
        NavigationStack{
            VStack{
                Link(destination: URL(string: "instagram.com/sophiahaggray")!) {
                    Text("Instagram")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                    
                }
            }
            
        }
    
    }


#Preview {
    ContactView()
}
