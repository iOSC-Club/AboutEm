//
//  MoreView.swift
//  AboutMe
//
//  Created by Hamza Wako on 2/11/26.
//

import SwiftUI

struct MoreView: View {
    var body: some View {
        NavigationStack{
            Form {
                Section("Skills"){
                    Text("Xcode")
                    Text("Concept Design")
                    Text("Graphic Design")
                    Text("Fashion Design")
                }
                
            
                    
                    
                }
                    
                }
        }
    }

#Preview {
    MoreView()
}
