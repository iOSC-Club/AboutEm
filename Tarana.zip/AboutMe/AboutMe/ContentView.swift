//
//  ContentView.swift
//  AboutMe
//
//  Created by Jacob Scheff on 2/11/26.
//

import SwiftUI

struct ContentView: View {
    let hobbies = ["Designing", "Music", "Games"]
    var body: some View {
        TabView {
            Tab("About", systemImage: "person") {
                AboutView()
            }
            
            Tab("Contact", systemImage: "phone") {
                ContactView()
            }
            
            Tab("More", systemImage: "ellipsis") {
                MoreView()
            }
        }
    }
}

#Preview {
    ContentView()
}
