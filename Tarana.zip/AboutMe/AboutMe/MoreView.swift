//
//  MoreView.swift
//  AboutMe
//
//  Created by Jacob Scheff on 2/11/26.
//

import SwiftUI

struct MoreView: View {
    var body: some View {
        NavigationStack {
            Form {
                Section("Skills") {
                    Text("Python")
                    Text("Java")
                    Text("Java")
                    Text("Unity")
                }
                
                Section("Languages") {
                    Text("English")
                    Text("Bengali")
                    Text("Spanish")
                }
            }
            .navigationTitle("More Info")
        }
    }
}

#Preview {
    MoreView()
}
