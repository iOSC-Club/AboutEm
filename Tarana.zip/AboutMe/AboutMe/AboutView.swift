//
//  AboutView.swift
//  AboutMe
//
//  Created by Jacob Scheff on 2/11/26.
//

import SwiftUI

struct AboutView: View {
    let hobbies = ["Designing", "Music", "Games"]
    var body: some View {
        ZStack {
            Color.purple
                .opacity(0.4)
                .ignoresSafeArea()
            
            VStack {
                Image("Primary")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(30)
                    .shadow(color: .blue, radius: 25)
                    .padding()
                
                Text("Hey, I'm Tarana Sharmin")
                    .font(.largeTitle)
                    .bold()
                    .multilineTextAlignment(.center)
                    .fontDesign(.rounded)
                
                Text("I love \(hobbies.formatted())")
                
                HStack {
                    Image(systemName: "iphone")
                    Image(systemName: "airtag.radiowaves.forward")
                }
                .imageScale(.large)
                .padding(10)
                .glassEffect(.regular.interactive())
                
                Spacer()
                    .frame(height: 20)
                
                Text("Fun Fact")
                    .font(.title3)
                    .bold()
                
                Text("WGI World Championship")
                
                Spacer()
                    .frame(height: 20)
                
                Text("Favorite Apple Product")
                    .font(.title3)
                    .bold()
                
                Text("AirTag")
            }
            .padding()
        }
    }
}

#Preview {
    AboutView()
}
