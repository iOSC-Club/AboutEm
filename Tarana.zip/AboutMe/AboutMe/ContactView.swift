//
//  ContactView.swift
//  AboutMe
//
//  Created by Jacob Scheff on 2/11/26.
//

import SwiftUI

struct ContactView: View {
    let hobbies = ["Designing", "Music", "Games"]
    var body: some View {
        NavigationStack {
            VStack {
                Link(destination: URL(string: "https://instrgram.com/rave1ty")!) {
                    Text("Instagram")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonStyle(.borderedProminent)
                .buttonBorderShape(.roundedRectangle(radius: 30))
            }
            .navigationTitle("Contact")
        }
    }
}

#Preview {
    ContactView()
}
