//
//  ContactView.swift
//  AboutMe
//
//  Created by Angela Chen on 2/11/26.
//

import SwiftUI

struct ContactView: View {
    var body: some View {
        NavigationStack{
            
            VStack(spacing: 20){
                Link(destination: URL(string: "instagram.com")!) {
                    Text("Instagram")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
                
                Link(destination: URL(string: "linkedin.com")!) {
                    Text("LinkedIn")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
            }
            
            
            
                .navigationTitle("Contact")
        }
    }
}

#Preview {
    ContactView()
}
