//
//  ContentView 2.swift
//  AboutMe
//
//  Created by Angela Chen on 2/11/26.
//


//
//  ContentView.swift
//  AboutMe
//
//  Created by Angela Chen on 2/11/26.
//

import SwiftUI

struct AboutView: View {
    
    let hobbies = ["french fries", "piano", "chocolate"]
    var body: some View {
        ZStack{
            Color.pink
                .opacity(0.3)
                .ignoresSafeArea()
            
            VStack {
                
                Image("IMG_2363")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(30)
                    .shadow(color: .pink, radius: 20)
                    .padding(.horizontal)
                
                
                Text("Hey, I'm Olivia Bovell")
                    .font(.largeTitle)
                    .bold()
                    .fontDesign(.rounded)
                
                Text("I love \(hobbies.formatted())")
                
                HStack{
                    Image(systemName: "iphone")
                    
                    Image(systemName: "pianokeys")
                    
                }
                .imageScale(.large)
                .padding()
                .glassEffect(.clear.tint(.pink).interactive())
                
                
                Spacer()
                    .frame(height: 20)
                
                Text("Fun Fact")
                    .font(.title3)
                    .bold()
                
                Text("I have never broken a bone")
                
                
                
                Text("Favorite Apple Product")
                    .font(.title3)
                    .bold()
                
                Text("AirPods")
                
                
            }
            .padding()
            .multilineTextAlignment(.center)
            
            
        }
    }
}

#Preview {
    ContentView()
}
