//
//  ContentView.swift
//  AboutMe
//
//  Created by Angela Chen on 2/11/26.
//

import SwiftUI

struct ContentView: View {
    
    let hobbies = ["french fries", "piano", "chocolate"]
    var body: some View {
        TabView{
            
            Tab("About", systemImage: "person"){
                AboutView()
            }
            
            Tab("About", systemImage: "phone"){
                ContactView()
            }
            
            Tab("About", systemImage: "ellipsis"){
                MoreView()
            }
        
            
        }
    }
}

#Preview {
    ContentView()
}
