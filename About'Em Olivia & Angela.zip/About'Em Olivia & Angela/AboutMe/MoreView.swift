//
//  MoreView.swift
//  AboutMe
//
//  Created by Angela Chen on 2/11/26.
//

import SwiftUI

struct MoreView: View {
    var body: some View {
        NavigationStack{
            Form{
                Section("Skills"){
                    Text("Xcode")
                    Text("C++")
                    Text("Python")
                    Text("LT Spice")
                }
                
                
                Section("Languages"){
                    Text("English")
                }
                
            }
            
            
            
            .navigationTitle("More Info")
            
        }
    }
}

#Preview {
    MoreView()
}
