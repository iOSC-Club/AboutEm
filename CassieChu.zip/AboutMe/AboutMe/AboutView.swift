//
//  AboutView.swift
//  AboutMe
//
//  Created by Vinayak Malviya on 11/2/26.
//


import SwiftUI

struct AboutView: View {
    let hobbies = ["Golfing", "Baking", "Travelling", "Rock Climbing"]

    var body: some View {
        ZStack {
            Color.purple
                .opacity(0.2).ignoresSafeArea()
            VStack {
                Image("Primary")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(20)
                    .shadow(color: .purple, radius: 16)
                    .padding(24)
                Text("Hey, I'm Cassie Chu")
                    .font(.largeTitle)
                    .bold()
                    .fontDesign(.rounded)
                Spacer()
                    .frame(height: 16)
                Text("I love \(hobbies.formatted(.list(type: .and)))")
                HStack {
                    Image(systemName: "figure.climbing.circle.fill")
                    Image(systemName: "iphone")
                    Image(systemName: "airplane.path.dotted")
                    Image(systemName: "figure.golf.circle.fill")
                }
                .imageScale(.large)
                .padding()
                .glassEffect(.regular.interactive())
                Spacer()
                    .frame(height: 16)
                Text("Fun Fact")
                    .font(.title3)
                    .bold()
                Text("I have a dog named Pika Chu")
                Spacer()
                    .frame(height: 14)
                Text("Favorite Apple Product")
                    .font(.title3)
                    .bold()
                Text("iPhone 15")
            }
            .padding()
            .multilineTextAlignment(.center)
        }
    }
}

#Preview {
    AboutView()
}
