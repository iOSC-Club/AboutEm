//
//  ContactView.swift
//  AboutMe
//
//  Created by Vinayak Malviya on 11/2/26.
//

import SwiftUI

struct ContactView: View {
    var body: some View {
        NavigationStack {
            VStack{
                Link(destination: URL(string: "https://instagram.com/cass_chu")!) {
                    Text("Instagram")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonStyle(.borderedProminent)
                .buttonBorderShape(.roundedRectangle(radius: 20))
                
                Link(destination: URL(string: "https://github.com/")!) {
                    Text("GitHub")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonStyle(.borderedProminent)
                .buttonBorderShape(.roundedRectangle(radius: 20))
                
                Link(destination: URL(string: "https://linkedin.com/in/")!) {
                    Text("LinkedIn")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonStyle(.borderedProminent)
                .buttonBorderShape(.roundedRectangle(radius: 20))
            }
                .navigationTitle("Contact")
        }
    }
}

#Preview {
    ContactView()
}
