//
//  MoreView.swift
//  AboutMe
//
//  Created by Vinayak Malviya on 11/2/26.
//

import SwiftUI

struct MoreView: View {
    var body: some View {
        NavigationStack {
            Form {
                Section("Skills") {
                    Text("Golfing")
                    Text("Canva")
                    Text("Excel")
                    Text("Baking")
                }
                
                Section("Languages") {
                    Text("English")
                    Text("Mandarin")
                }
            }.navigationTitle("More Info")
        }
    }
}

#Preview {
    MoreView()
}
