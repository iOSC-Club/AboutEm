//
//  ContactView.swift
//  AboutMe
//
//  Created by Shreyans Jain on 2/11/26.
//

import SwiftUI

struct ContactView: View {
    var body: some View {
        NavigationStack{
            VStack(spacing: 20){
                Link(destination: URL(string:"instagram.com/pansiraphop")!) {
                    Text("Instagram")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 30))
                .buttonStyle(.borderedProminent)
                
                Link(destination: URL(string:"linkedin.in/panpitpree")!) {
                    Text("LinkedIn")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 30))
                .buttonStyle(.borderedProminent)
                
                Link(destination: URL(string:"instagram.com/pansiraphop")!) {
                    Text("GitHub")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 30))
                .buttonStyle(.borderedProminent)
                
                Link(destination: URL(string:"instagram.com/pansiraphop")!) {
                    Text("Twitter")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 30))
                .buttonStyle(.borderedProminent)

            }
                .navigationTitle("Contact")
        }
    }
}

#Preview {
    ContactView()
}
