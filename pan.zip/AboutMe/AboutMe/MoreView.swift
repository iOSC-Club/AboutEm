//
//  MoreView.swift
//  AboutMe
//
//  Created by Shreyans Jain on 2/11/26.
//

import SwiftUI

struct MoreView: View {
    var body: some View {
        NavigationStack{
            Form{
                Section("Skills"){
                    Text("Xcode")
                    Text("HTML")
                    Text("CSS")
                    Text("Next.js")
                    Text("Supabase")
                }
                Section("Languages"){
                    Text("English")
                    Text("Thai")
                }
            }
            .navigationTitle("More Info")
        }
    }
}

#Preview {
    MoreView()
}
