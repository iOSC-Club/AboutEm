//
//  ContentView 2.swift
//  AboutMe
//
//  Created by Shreyans Jain on 2/11/26.
//


import SwiftUI

struct AboutView: View {
    let hobbies: [String] = ["cycling", "hiking", "playing with robots"]
    let accessories: [String] = ["iphone", "macbook.gen2", "applewatch.watchface", "airpods.pro.chargingcase.wireless.fill", "ipad.landscape"]
    var body: some View {
        ZStack {
            Color.brown
                .opacity(0.4)
                .ignoresSafeArea()
            VStack {
                Image("Primary")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(23)
                    .shadow(color: .brown, radius: 20)
                    .padding()
                
                Text("Hey, I'm Pan Pitpreecha")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .multilineTextAlignment(.center)
                    .fontDesign(.rounded)
                
                Text("I love \(hobbies.formatted())")
                
                HStack {
                    ForEach(accessories, id: \.self) { symbol in
                        Image(systemName: symbol)
                    }
                }
                .imageScale(.large)
                .padding()
                .glassEffect(.regular.interactive())
                
                Spacer()
                    .frame(height: 20)
                
                Text("Fun Fact").font(.title3).bold()
                Text("I have 280,000 km on flighty")
                
                Text("Favorite Apple Product")
                    .font(.title3)
                    .bold()
                Text("Airpods Pro")
                
            }
            .padding()
            .multilineTextAlignment(.center)
        }
    }
}

#Preview {
    ContentView()
}
