//
//  AboutMeApp.swift
//  AboutMe
//
//  Created by Arya Shirke on 2/11/26.
//

import SwiftUI

@main
struct AboutMeApp: App {
    var body: some Scene {
        WindowGroup {
            AboutView()
        }
    }
}
