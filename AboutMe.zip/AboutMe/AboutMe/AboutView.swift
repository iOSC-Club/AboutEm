//
//  AboutView.swift
//  AboutMe
//
//  Created by Arya Shirke on 2/11/26.
//

import SwiftUI

struct AboutView: View {
    let hobbies = ["horseriding","skiing", "eating carrots"]
    var body: some View {
        ZStack {
            Color.orange
                .opacity(0.1)
                ignoresSafeArea()
            VStack {
                Image("Primary")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(25)
                    .shadow(color: .orange, radius: 25)
                    .padding()
                Text("Hi, I'm Laura Jun!")
                    .font(.largeTitle)
                    .bold()
                    .padding()
                    .fontDesign(.serif)
                
                Text("I love \(hobbies.formatted())")
                
                HStack{
                    Image(systemName: "iphone")
                    Image(systemName: "ipad")
                    Image(systemName: "macbook.gen2")
                    Image(systemName: "airpods.max")
                }
                .imageScale(.large)
                .padding()
                .glassEffect(.regular.tint(.orange).interactive(true))
                
                Spacer()
                    .frame(height: 30)
                Text("Fun Fact")
                    .font(.title)
                    .bold()
                Text("I have an extra bone in my back!")
                
                Spacer()
                    .frame(height: 30)
                Text("Favorite Apple Product")
                font(.title)
                    .bold()
                Text("Iphone")
                    .padding()
                    .multilineTextAlignment(.center)
            }
        }
    }
}

#Preview {
    ContentView()
     
}
