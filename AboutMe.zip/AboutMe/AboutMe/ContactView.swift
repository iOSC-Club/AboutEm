//
//  ContactView.swift
//  AboutMe
//
//  Created by Arya Shirke on 2/11/26.
//

import SwiftUI

struct ContactView: View {
    var body: some View {
        NavigationStack{
            VStack{
                Link(destination: URL(string: "instagram.com/laurajunnn")!){
                    Text("Instagram")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
                
                Link(destination: URL(string: "instagram.com/laurajunnn")!){
                    Text("LinkedIn")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
                
                Link(destination: URL(string: "instagram.com/laurajunnn")!){
                    Text("X (Twitter)")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
                
                Link(destination: URL(string: "instagram.com/laurajunnn")!){
                    Text("Github")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
            }
        }
    }
}

#Preview {
    ContactView()
}
