//
//  MoreView.swift
//  AboutMe
//
//  Created by Arya Shirke on 2/11/26.
//

import SwiftUI

struct MoreView: View {
    var body: some View {
        NavigationStack {
            Form {
                Section("Skills") {
                    Text("Xcode")
                    Text("Horseriding")
                    Text("Skiing")
                }
                Section("Favorite Things to Eat"){
                    Text("Carrots")
                    Text("Apples")
                    Text("Bananas")
                }
            }
            .navigationBarTitle("More")
        }
    }
}

#Preview {
    MoreView()
}
