//
//  ContactView.swift
//  AboutMe
//
//  Created by Om Chachad on 11/02/26.
//

import SwiftUI

struct ContactView: View {
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Link(destination: URL(string: "https://instagram.com/itechirl")!) {
                    Text("Instagram")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
                
                Link(destination: URL(string: "https://twitter.com/TheOriginaliTE")!) {
                    Text("Twitter")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
                
                Link(destination: URL(string: "https://github.com/TheOriginaliTE")!) {
                    Text("GitHub")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
                
                Link(destination: URL(string: "https://linkedin.com/in/omchachad")!) {
                    Text("Linkedin")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
            }
            .navigationTitle("Contact")
        }
    }
}

#Preview {
    ContactView()
}
