//
//  MoreView.swift
//  AboutMe
//
//  Created by Om Chachad on 11/02/26.
//

import SwiftUI

struct MoreView: View {
    var body: some View {
        NavigationStack {
            Form {
                Section("Skills") {
                    Text("Xcode")
                    Text("Swift")
                    Text("Python")
                    Text("Java")
                }
                
                Section("Languages") {
                    Text("English")
                    Text("Marathi")
                    Text("Hindi")
                    Text("Spanish")
                }
            }
            .navigationTitle("More Info")
        }
    }
}

#Preview {
    MoreView()
}
