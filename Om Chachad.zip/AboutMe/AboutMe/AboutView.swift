//
//  AboutView.swift
//  AboutMe
//
//  Created by Om Chachad on 11/02/26.
//

import SwiftUI

struct AboutView: View {
    let hobbies = ["Programming", "3D Printing", "Cooking", "Coffee Chatting"]
    
    var body: some View {
        ZStack {
            Color.blue
                .opacity(0.3)
                .ignoresSafeArea()
            
            VStack {
                Image("Primary")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(30)
                    .shadow(radius: 20)
                    .padding()
                
                Text("Hey, I'm Om Chachad")
                    .font(.largeTitle)
                    .bold()
                    .fontDesign(.serif)
                
                Text("I love \(hobbies.formatted())")
                
                
                HStack {
                    Image(systemName: "iphone")
                    Image(systemName: "ipad")
                    Image(systemName: "macbook")
                    Image(systemName: "desktopcomputer")
                    Image(systemName: "visionpro")
                    Image(systemName: "airpods")
                }
                .imageScale(.large)
                .padding()
                .glassEffect(.regular.interactive())
                
                Spacer()
                    .frame(height: 20)
                
                Text("Fun Fact")
                    .font(.title3)
                    .bold()
                
                Text("I used to be able to walk with my feed 180º backwards.")
                
                Spacer()
                    .frame(height: 20)
                
                Text("Favorite Apple Product")
                    .font(.title3)
                    .bold()
                
                Text("Apple Vision Pro")
            }
            .padding()
            .multilineTextAlignment(.center)
        }
    }
}

#Preview {
    AboutView()
}
