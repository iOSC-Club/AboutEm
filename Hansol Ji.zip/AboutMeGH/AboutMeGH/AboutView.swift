import SwiftUI

struct AboutView: View {
    let hobbies = ["watching Formula 1", "playing soccer"]
    
    var body: some View {
        ZStack {
            Color.green.opacity(0.3)
            VStack {
                Image("Photo")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(20)
                    .shadow(color: .green, radius:20)
                    .padding(40)
                
                Text("Hansol Ji")
                    .font(.system(size: 50, weight: .bold, design: .rounded))
                
                Text("I love \(hobbies.formatted())")
                    .bold()
                    .fontDesign(.rounded)
                
                HStack{
                    Image(systemName: "iphone")
                    Image(systemName: "macbook")
                    Image(systemName: "airpods")
                }.imageScale(.large)
                .padding()
                .glassEffect(.regular.interactive())
                
                Spacer()
                    .frame(height:20)
                
                Text("I was in the army")
                    .bold()
                    .fontDesign(.rounded)
                
                Text("Macbook")
                    .bold()
                    .fontDesign(.rounded)
            }
        }
        
    }
}

#Preview {
    AboutView()
}
