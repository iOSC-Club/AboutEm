import SwiftUI

struct MoreView: View {
    var body : some View {
        NavigationStack {
            Form {
                Section("Skills") {
                    Text("Xcode")
                    Text("Soccer")
                    Text("Python")
                    
                }
                Section("Language") {
                    Text("English")
                    Text("Korean")
                }
            }.navigationTitle("More Info")
        }
    }
}

#Preview {
    MoreView()
}
