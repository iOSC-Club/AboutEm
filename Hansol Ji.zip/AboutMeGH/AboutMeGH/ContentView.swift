//
//  ContentView.swift
//  AboutMeGH
//
//  Created by Audrianne Gunawan on 2/11/26.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            AboutView()
                .tabItem {
                    Label("Contact", systemImage:"person")
                }
           ContactView()
                .tabItem {
                    Label("Contact", systemImage:"phone")
                }
            
            MoreView()
                .tabItem {
                    Label("Contact", systemImage:"ellipsis")
                }
        }
    }
}

#Preview {
    ContentView()
}
