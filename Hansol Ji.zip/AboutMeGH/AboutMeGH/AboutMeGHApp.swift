//
//  AboutMeGHApp.swift
//  AboutMeGH
//
//  Created by Audrianne Gunawan on 2/11/26.
//

import SwiftUI

@main
struct AboutMeGHApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
