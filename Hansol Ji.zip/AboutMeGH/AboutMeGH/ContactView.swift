import SwiftUI

struct ContactView: View {
    var body : some View {
        NavigationStack {
            VStack {
                Link(destination: URL(string: "https://www.instagram.com/_hansol.ji/")!) {
                    Text("Instagram")
                        .font(.largeTitle)
                        .padding()
                }.buttonBorderShape(.roundedRectangle(radius:20))
                    .buttonStyle(.borderedProminent)
            }.navigationTitle("Contact")
        }
    }
}

#Preview {
    ContactView()
}
