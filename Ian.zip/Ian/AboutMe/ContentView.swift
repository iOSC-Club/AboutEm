//
//  ContentView.swift
//  AboutMe
//
//  Created by Student on 2/11/26.
//

import SwiftUI

struct ContentView: View {
    let hobbies = ["jailbreaking", "coding", "programming", "school"]
    var body: some View {
        TabView {
            Tab("About", systemImage: "person") {
                AboutView()
            }
            
            Tab("Contact", systemImage: "phone") {
                ContactView()
            }
            
            Tab("More", systemImage: "ellipsis") {
                MoreView()
            }
            
//
//            ContactView()
//            
//            MoreView()
        }
//        ZStack {
//            Color.green
//                .opacity(0.3)
//                .ignoresSafeArea()
//            VStack {
//                Image("Primary")
//                    .resizable()
//                    .scaledToFit()
//                    .cornerRadius(20)
//                    .shadow(radius: 20)
//                    .shadow(color: .primary, radius: 20)
//                    .padding()
//                
//                Text("Hey, I'm Ian Tseng")
//                    .font(.largeTitle)
//                    .bold()
//                    .fontDesign(.serif)
//                
//                Text("I love \(hobbies.formatted())");
//                HStack {
//                    Image(systemName: "pc");
//                    Image(systemName: "iphone");
//                    Image(systemName: "airpods");
//                }
//                .imageScale(.large)
//                .padding()
//                
//                
//                
//                Text("fun Fact")
//                    .font(.title3)
//                    .bold()
//                
//                Spacer()
//                    .frame(height: 20)
//                
//                Text("Made a hackintosh")
//                    .font(.title3)
//                    .bold()
//                
//                Spacer()
//                    .frame(height: 20)
//                
//                Text("Favorite Apple product");
//                
//                Text("Iphone")
//                    .font(.title3)
//            }
//            .padding()
//            .multilineTextAlignment(.center)
//        }
    }
}

#Preview {
    ContentView()
}
