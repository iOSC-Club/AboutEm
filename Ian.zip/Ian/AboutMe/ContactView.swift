//
//  ContactView.swift
//  AboutMe
//
//  Created by Student on 2/11/26.
//

import SwiftUI

struct ContactView: View {
    var body: some View {
        NavigationStack {
            VStack {
                Link(destination: URL(string: "https://instagram.com/some")!) {
                    Text("Instagram")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
            }
            .navigationTitle("Contact")

        }
    }
}

#Preview {
    ContactView()
}
