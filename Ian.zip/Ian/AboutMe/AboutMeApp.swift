//
//  AboutMeApp.swift
//  AboutMe
//
//  Created by Student on 2/11/26.
//

import SwiftUI

@main
struct AboutMeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
