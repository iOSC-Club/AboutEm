//
//  MoreView.swift
//  AboutMe
//
//  Created by Student on 2/11/26.
//

import SwiftUI

struct MoreView: View {
    var body: some View {
        NavigationStack {
            Form {
                Section("Skills") {
                    Text("Xcode")
                    Text("jailbreaking")
                    Text("shell")
                    Text("Always thirsty")
                }
                Section("Languages") {
                    Text("English")
                    Text("Chinese")
                    Text("French")
                }
            }

            .navigationTitle("More Info")
        }
    }
}

#Preview {
    MoreView()
}
