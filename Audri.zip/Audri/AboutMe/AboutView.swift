//
//  AboutView.swift
//  AboutMe
//
//  Created by Hansol Ji on 2/11/26.
//

import SwiftUI

struct AboutView: View {
    let hobbies = ["Programming", "Playing Basketball", "Playing Tennis"]
    var body: some View {
        ZStack {
            Color.mint
                .opacity(0.3)
                .ignoresSafeArea()
            
            VStack {
                Image("Picture")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(30)
                    .shadow(radius: 5)
                    .shadow(color: .blue, radius: 20)
                    .padding(.leading)
                        
                Text("Audrianne Gunawan")
                    .font(.system(size: 35))
                    .bold()
                    .multilineTextAlignment(.center)
                    .fontDesign(.rounded)
                    
                
                Text("I love \(hobbies.formatted())")
                
                HStack {
                    Image(systemName: "iphone")
                        .imageScale(.large)
                    Image(systemName: "macbook")
                        .imageScale(.large)
                    Image(systemName: "airpods")
                        .imageScale(.large)
                    Image(systemName: "applewatch")
                        .imageScale(.large)
                    
                }
                .imageScale(.large)
                .padding()
                .glassEffect(.regular.interactive())
                
                Spacer()
                    .frame(height: 20)
                
                Text("Fun Fact")
                    .font(.title3)
                    .bold()
                Text("I have 4 dogs")
                
                Spacer()
                    .frame(height: 20)
                
                Text("Favorite Apple Product")
                    .font(.title3)
                    .bold()
                Text("My iPhone")
                
                
            }
        }
        
        .padding()
        .multilineTextAlignment(.center)
        .fontDesign(.rounded)
    }
}

#Preview {
    AboutView()
}
