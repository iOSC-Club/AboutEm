//
//  MoreView.swift
//  AboutMe
//
//  Created by Hansol Ji on 2/11/26.
//

import SwiftUI

struct MoreView: View {
    var body: some View {
        NavigationStack {
            Form {
                Section("Skills") {
                    Text("Xcode")
                    Text("Basketball")
                    Text("Python")
                }
                
                Section("Languages") {
                    Text("English")
                    Text("Indonesian")
                    Text("Chinese")
                    
                }
            }
        }
        .navigationTitle("More Info")
    }
}

#Preview {
    MoreView()
}
