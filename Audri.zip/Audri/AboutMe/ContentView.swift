//
//  ContentView.swift
//  AboutMe
//
//  Created by Hansol Ji on 2/11/26.
//

import SwiftUI

struct ContentView: View {

    var body: some View {
        
        TabView {
            Tab("About", systemImage: "person") {
                AboutView()
            }
            Tab("ContactsView", systemImage: "phone") {
                ContactsView()
            }
            Tab("MoreView", systemImage: "ellipsis") {
                MoreView()
            }
            
        }
        

    }
}

#Preview {
    ContentView()
}
