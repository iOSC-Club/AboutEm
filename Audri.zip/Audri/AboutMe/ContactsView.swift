//
//  ContactsView.swift
//  AboutMe
//
//  Created by Hansol Ji on 2/11/26.
//

import SwiftUI

struct ContactsView: View {
    var body: some View {
        NavigationStack {
            VStack {
                Link(destination: URL(string: "https://www.instagram.com/audri.g/")!) {
                    Text("Instagram")
                        .font(.largeTitle)
                        .padding()
                }
               
                .buttonStyle(.borderedProminent)
                
                
            }
            .navigationTitle(Text("Contact"))
        }
        
        
    }
}

#Preview {
    ContactsView()
}
